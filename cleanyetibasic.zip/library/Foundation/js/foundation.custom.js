/*jslint unparam: true, browser: true, indent: 2 */

jQuery(document).ready(function ($)
{
    $('#submit').attr('class', 'small button radius');
    $('.entry-utility').find('.content').find('a').attr('class', 'tiny button radius');
    $('.sticky').find('.post').addClass('panel radius');
    $('#main').find('img').addClass('th');
    $('#footer').find('img').addClass('th');


    $('#secondary').find('dd').each(function ()
    {
        var ddid = $(this).attr('id');
        $(this).find('.content').attr('id', 'panel-' + ddid);
    });
});