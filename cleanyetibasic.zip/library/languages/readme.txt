cleanyetibasic is built off Thematic Framework

If you find that your locale for cleanyetibasic is not completely translated,
please come to http://translate.thematicitheme.com find the latest "active" subproject 
of the thematic-framework and help us internationalize the theme.

If you would like to add a new locale to Thematic or become a validator for your locale 
please come and open an issue describing your request here: https://github.com/ThematicTheme/Thematic/issues
and we will make it happen.
