<?php
/**
 * Search Form Template
 *
 * …
 * 
 * @package cleanyetibasic
 * @subpackage Templates
 */
    
    // calls the search form
	cleanyetibasic_search_form();
?>